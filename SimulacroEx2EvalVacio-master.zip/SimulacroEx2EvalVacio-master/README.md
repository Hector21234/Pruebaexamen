Examen tipo 2a Evaluación Despliegue de Aplicaciones Web.


Deberás de:
-Escribir al menos 2 test unitarios
-Configurar GitHubActions para:
  -Establecer CI de manera que se automaticen los tests que has creado
  -Establecer CD de manera que cuando sean exitosas las pruebas se cree una imagen en DockerHub guardando el histórico de imágenes que se van generando.
  
  Probando actions por petición de la clase. Cambiando versión de la action de phpunit en el yml.
.
